# coc7-jmn
Ce module force la modification de certaines fonctions du "System Foundry VTT "Cthulhu V7"

# CE MODULE EST DESTINE A UN USAGE PRIVE

A ce jour, les modifications actives :
- Suppression des images de fond pour les points de vie et SAN sur la feuille de personnage.
- Ajout possibilité de modifier l'icône de status DEAD

## Attributions
Icons from game-icons.net  