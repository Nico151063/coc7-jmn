export const MODULE = "coc7-jmn"; //module name
export const DEATH_ICON_FILENAME = `modules/${MODULE}/icons/death-skull-noback.svg`; 